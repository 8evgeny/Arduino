#include "Arduino.h"

void showRGB1(boolean r, boolean g, boolean b){
  digitalWrite(PIN_LED_RED, r);
  digitalWrite(PIN_LED_GREEN, g);
  digitalWrite(PIN_LED_BLUE, b);
}
void showRGB2(boolean r, boolean g, boolean b){
  digitalWrite(PIN_LED_RED2, r);
  digitalWrite(PIN_LED_GREEN2, g);
  digitalWrite(PIN_LED_BLUE2, b);
}
