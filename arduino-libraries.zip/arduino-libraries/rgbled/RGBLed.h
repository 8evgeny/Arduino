/* RFID.h - Library to use ARDUINO RFID MODULE KIT 13.56 MHZ WITH TAGS SPI W AND R BY COOQROBOT.
 * Based on code Dr.Leong   ( WWW.B2CQSHOP.COM )
 * Created by Miguel Balboa (circuitito.com), Jan, 2012. 
 */ 


const int PIN_LED_RED = 3;
const int PIN_LED_GREEN = 5;
const int PIN_LED_BLUE = 6;

const int PIN_LED_RED2 = 9;
const int PIN_LED_GREEN2 = 10;
const int PIN_LED_BLUE2 = 11;
